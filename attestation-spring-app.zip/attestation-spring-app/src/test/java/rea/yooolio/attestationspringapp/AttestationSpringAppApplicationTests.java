package rea.yooolio.attestationspringapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttestationSpringAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
